<?php
/*********************************************************************************
 ********************************************************************************/


$manifest = array (
  'acceptable_sugar_versions' => array (),
  'acceptable_sugar_flavors' => array (),
  'readme' => '',
  'key' => '',
  'author' => 'kuske',
  'description' => '',
  'icon' => '',
  'is_uninstallable' => true,
  'name' => 'new_prune_database',
  'published_date' => '2013-02-15 15:58:31',
  'type' => 'module',
  'version' => '2013-0002',
//  'remove_tables' => 'prompt',
);

$installdefs = array (
  'id' => 'new_prune_database',
  'language' => 
  array (
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Schedulers/new_prune_database.php',
      'to' => 'custom/Extension/modules/Schedulers/Ext/ScheduledTasks/new_prune_database.php',
    ),
  ),
);

?>